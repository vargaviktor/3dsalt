Install:

Copy the folder to file to /3ds/wolf4sdl/
